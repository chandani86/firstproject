import { Component, OnInit } from '@angular/core';
import UserListJson from '../userlist.json';
import { ActivatedRoute, ParamMap, Router  } from '@angular/router'
import { Request } from "express"
export interface IGetUserAuthInfoRequest extends Request {
  user: string // or any other type
}
  
interface USERS {
    // name: String;
    url: String;
    label:String
}

@Component({
  selector: 'app-conversion',
  templateUrl: './conversion.component.html',
  styleUrls: ['./conversion.component.css']
})
export class ConversionComponent implements OnInit {

  title = 'The Query Times';
  msg:string | undefined;
  msg1!: 0;
  submenu: string= " " ;
  method: any;
  input: string= " " ;
  output: string= " " ;


  Users: USERS[] = UserListJson;
  constructor(private route: ActivatedRoute, private router: Router) {
    console.log(this.Users);
    this.method = 'DecimalToBinary';    
    
   }
  ngOnInit(): void {
    //throw new Error('Method not implemented.');
    this.submenu = 'DecimalToBinary';//this.route.snapshot.paramMap.get('submenu') as string;
    let values = this.submenu.split("To");
    this.input = values[0];
    this.output = values[1];
     
  }

  functionName() {
    this.convert.call(this);
  }

  convert(this: any){
    let decimal = this.msg1;
    var toBinary = (+decimal).toString(2);
    //console.log(toBinary);
    this.msg= toBinary;
    return this.msg; 
  }

}
